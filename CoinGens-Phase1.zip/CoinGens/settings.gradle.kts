rootProject.name = "CoinGens"

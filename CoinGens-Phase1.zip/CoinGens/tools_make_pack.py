"""Generates the CoinGens resource pack (textures + models + zip). Run: python3 tools_make_pack.py"""
import hashlib, json, math, os, zipfile
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resourcepack")
SRC = os.path.join(OUT, "src")
NS = os.path.join(SRC, "assets", "coingens")

COINS = {"bronze": (205, 127, 50), "silver": (205, 212, 225), "gold": (255, 200, 40)}
GENS = {  # tier: (base color, accent color)
    "copper":  ((190, 105, 65),  COINS["bronze"]),
    "iron":    ((175, 178, 188), COINS["silver"]),
    "gold":    ((235, 185, 50),  COINS["gold"]),
    "diamond": ((60, 190, 205),  COINS["silver"]),
    "emerald": ((45, 185, 95),   COINS["gold"]),
}

def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c) + (255,)

def gen_texture(base, accent):
    im = Image.new("RGBA", (16, 16))
    px = im.load()
    for y in range(16):
        for x in range(16):
            noise = ((x * 7 + y * 13) % 5) - 2
            v = shade(base, 1 + noise * 0.025)
            edge = min(x, y, 15 - x, 15 - y)
            if edge == 0:
                v = shade(base, 0.5)
            elif edge == 1:
                v = shade(base, 1.3) if (x == 1 or y == 1) and x != 14 and y != 14 else shade(base, 0.75)
            if 4 <= x <= 11 and 4 <= y <= 11:
                v = shade(base, 0.5)
                d = math.hypot(x - 7.5, y - 7.5)
                if d <= 2.2:
                    v = shade(accent, 1.0)
                elif d <= 3.1:
                    v = shade(accent, 0.55)
            px[x, y] = v
    for (x, y) in [(2, 2), (13, 2), (2, 13), (13, 13)]:
        px[x, y] = shade(base, 1.55)
    px[6, 6] = shade(accent, 1.35)
    return im

def coin_texture(base):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - 7.5, y - 7.5)
            if d > 6.8:
                continue
            if d > 5.7:
                v = shade(base, 0.55)
            elif d > 4.6:
                v = shade(base, 1.2)
            else:
                v = shade(base, 0.95)
                if 2.0 <= d <= 3.1 and not (x > 9 and abs(y - 7.5) < 1.6):
                    v = shade(base, 0.65)
            px[x, y] = v
    for (x, y) in [(4, 4), (5, 3), (3, 5)]:
        px[x, y] = shade(base, 1.55)
    return im

def write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def save_png(im, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    im.save(path)

for cid, col in COINS.items():
    save_png(coin_texture(col), f"{NS}/textures/item/coin_{cid}.png")
    write_json(f"{NS}/models/item/coin_{cid}.json",
               {"parent": "minecraft:item/generated", "textures": {"layer0": f"coingens:item/coin_{cid}"}})
    write_json(f"{NS}/items/coin_{cid}.json",
               {"model": {"type": "minecraft:model", "model": f"coingens:item/coin_{cid}"}})

for tid, (base, accent) in GENS.items():
    save_png(gen_texture(base, accent), f"{NS}/textures/block/gen_{tid}.png")
    write_json(f"{NS}/models/block/gen_{tid}.json",
               {"parent": "minecraft:block/cube_all", "textures": {"all": f"coingens:block/gen_{tid}"}})
    write_json(f"{NS}/items/gen_{tid}.json",
               {"model": {"type": "minecraft:model", "model": f"coingens:block/gen_{tid}"}})

write_json(f"{SRC}/pack.mcmeta", {"pack": {
    "description": "CoinGens resource pack",
    "pack_format": 46,
    "supported_formats": {"min_inclusive": 46, "max_inclusive": 99}}})
coin_texture(COINS["gold"]).resize((128, 128), Image.NEAREST).save(f"{SRC}/pack.png")

zip_path = os.path.join(OUT, "CoinGens-Pack.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(SRC):
        for name in sorted(files):
            full = os.path.join(root, name)
            z.write(full, os.path.relpath(full, SRC))
print("sha1:", hashlib.sha1(open(zip_path, "rb").read()).hexdigest())

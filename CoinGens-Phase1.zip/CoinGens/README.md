# CoinGens (Phase 1)

Coin generators for Paper 1.21.4+ with a custom resource pack. Not compiled/tested yet.

## Build
Needs JDK 21 and Gradle 8+ (or import the folder into IntelliJ):

    gradle build

The jar ends up in `build/libs/CoinGens-0.1.0.jar` -> put it into your server's `plugins/` folder.

## Resource pack
`resourcepack/CoinGens-Pack.zip` (regenerate with `python3 tools_make_pack.py`, needs Pillow).
Host the zip somewhere with a direct link (e.g. a GitHub release) and set in `server.properties`:

    resource-pack=<direct link to the zip>
    resource-pack-sha1=<sha1 printed by the script>
    require-resource-pack=true

## Usage
- `/cg give <player> <tier> [level] [amount]` (admin)
- `/cg coins <player> <coin> <amount>` (admin)
- `/cg balance`, `/cg reload`
- Place a generator, right-click with an empty hand = collect, sneak + right-click (empty hand) = upgrade.

Tiers/coins/balance: `plugins/CoinGens/generators.yml`, texts: `plugins/CoinGens/lang/en_US.yml`.

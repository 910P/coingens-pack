package com.coingens;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Owns all placed generators: ticking, display entities, upgrades, saving. */
public final class GeneratorManager {

    public record BlockPos(UUID world, int x, int y, int z) {
        public static BlockPos of(Block b) {
            return new BlockPos(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ());
        }
    }

    public static final class PlacedGenerator {
        final BlockPos pos;
        final UUID owner;
        String tierId;
        int level;
        long stored;
        int progress;
        UUID displayId;
        UUID holoId;

        PlacedGenerator(BlockPos pos, UUID owner, String tierId, int level) {
            this.pos = pos;
            this.owner = owner;
            this.tierId = tierId;
            this.level = level;
        }
    }

    private final CoinGensPlugin plugin;
    private final Map<BlockPos, PlacedGenerator> gens = new HashMap<>();
    private final File file;
    private BukkitTask task;
    private int sinceSave;

    public GeneratorManager(CoinGensPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public void start() {
        load();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public void stop() {
        if (task != null) task.cancel();
        save();
        for (PlacedGenerator g : gens.values()) removeEntities(g);
    }

    // ---------- lookup ----------

    public PlacedGenerator at(Block block) {
        return gens.get(BlockPos.of(block));
    }

    public int countOwned(UUID owner) {
        int n = 0;
        for (PlacedGenerator g : gens.values()) {
            if (owner.equals(g.owner)) n++;
        }
        return n;
    }

    // ---------- items ----------

    public ItemStack createItem(Tier tier, int level, int amount) {
        ItemStack item = new ItemStack(tier.block(), amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Lang.mm(tier.name()));
        meta.lore(plugin.lang().components("gen-lore", resolvers(tier, level, 0)));
        NamespacedKey model = NamespacedKey.fromString(tier.model());
        if (model != null) meta.setItemModel(model);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(plugin.keys().genTier, PersistentDataType.STRING, tier.id());
        pdc.set(plugin.keys().genLevel, PersistentDataType.INTEGER, level);
        item.setItemMeta(meta);
        return item;
    }

    public Tier tierOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer()
                .get(plugin.keys().genTier, PersistentDataType.STRING);
        return plugin.catalog().tier(id);
    }

    public int levelOf(ItemStack item) {
        Integer level = item.getItemMeta().getPersistentDataContainer()
                .get(plugin.keys().genLevel, PersistentDataType.INTEGER);
        return level == null ? 1 : Math.max(1, level);
    }

    // ---------- actions ----------

    public void place(Block block, Tier tier, int level, UUID owner) {
        PlacedGenerator g = new PlacedGenerator(BlockPos.of(block), owner, tier.id(),
                Math.max(1, Math.min(level, tier.maxLevel())));
        gens.put(g.pos, g);
        ensureEntities(g, block.getWorld());
    }

    public void pickup(Player player, PlacedGenerator g) {
        Tier tier = plugin.catalog().tier(g.tierId);
        gens.remove(g.pos);
        removeEntities(g);
        if (tier == null) return;
        player.getInventory().addItem(createItem(tier, g.level, 1)).values()
                .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
        if (g.stored > 0) {
            plugin.coins().giveType(player, plugin.catalog().coin(tier.coinId()), g.stored);
        }
        plugin.lang().send(player, "picked-up");
    }

    public void collect(Player player, PlacedGenerator g) {
        Tier tier = plugin.catalog().tier(g.tierId);
        if (tier == null) return;
        if (g.stored <= 0) {
            plugin.lang().send(player, "nothing-to-collect");
            return;
        }
        TagResolver[] r = resolvers(tier, g.level, g.stored);
        plugin.coins().giveType(player, plugin.catalog().coin(tier.coinId()), g.stored);
        g.stored = 0;
        refreshHolo(g);
        plugin.lang().send(player, "collected", r);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.3f);
        World w = player.getWorld();
        w.spawnParticle(Particle.HAPPY_VILLAGER, center(g, w).add(0, 0.8, 0), 10, 0.3, 0.3, 0.3, 0);
    }

    public void upgrade(Player player, PlacedGenerator g) {
        Tier tier = plugin.catalog().tier(g.tierId);
        if (tier == null) return;
        if (g.level >= tier.maxLevel()) {
            plugin.lang().send(player, "max-level");
            return;
        }
        long cost = tier.upgradeCost(g.level);
        if (!plugin.coins().charge(player, cost)) {
            plugin.lang().send(player, "cannot-afford", resolvers(tier, g.level, g.stored));
            return;
        }
        g.level++;
        refreshHolo(g);
        plugin.lang().send(player, "upgraded", resolvers(tier, g.level, g.stored));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
        World w = player.getWorld();
        w.spawnParticle(Particle.TOTEM_OF_UNDYING, center(g, w).add(0, 0.8, 0), 20, 0.4, 0.4, 0.4, 0.1);
    }

    public void refreshAll() {
        for (PlacedGenerator g : gens.values()) refreshHolo(g);
    }

    // ---------- ticking ----------

    private void tick() {
        Iterator<PlacedGenerator> it = gens.values().iterator();
        while (it.hasNext()) {
            PlacedGenerator g = it.next();
            World w = Bukkit.getWorld(g.pos.world());
            if (w == null || !w.isChunkLoaded(g.pos.x() >> 4, g.pos.z() >> 4)) continue;

            // Block vanished (WorldEdit, etc.): clean up.
            if (w.getBlockAt(g.pos.x(), g.pos.y(), g.pos.z()).getType().isAir()) {
                removeEntities(g);
                it.remove();
                continue;
            }
            Tier tier = plugin.catalog().tier(g.tierId);
            if (tier == null) continue;

            ensureEntities(g, w);
            if (++g.progress >= tier.intervalSeconds()) {
                g.progress = 0;
                long cap = tier.capacityAt(g.level);
                if (g.stored < cap) {
                    g.stored = Math.min(cap, g.stored + tier.amountAt(g.level));
                    refreshHolo(g);
                }
            }
        }
        if (++sinceSave >= Math.max(30, plugin.getConfig().getInt("autosave-seconds", 300))) {
            sinceSave = 0;
            save();
        }
    }

    // ---------- display entities ----------

    private Location center(PlacedGenerator g, World w) {
        return new Location(w, g.pos.x() + 0.5, g.pos.y() + 0.5, g.pos.z() + 0.5);
    }

    private void ensureEntities(PlacedGenerator g, World w) {
        Tier tier = plugin.catalog().tier(g.tierId);
        if (tier == null) return;

        Entity display = g.displayId == null ? null : Bukkit.getEntity(g.displayId);
        if (display == null || !display.isValid()) {
            ItemStack stack = createItem(tier, g.level, 1);
            ItemDisplay spawned = w.spawn(center(g, w), ItemDisplay.class, d -> {
                d.setItemStack(stack);
                d.setTransformation(new Transformation(
                        new Vector3f(0, 0, 0), new AxisAngle4f(0, 0, 0, 1),
                        new Vector3f(1.002f, 1.002f, 1.002f), new AxisAngle4f(0, 0, 0, 1)));
                d.setPersistent(false);
                d.setInvulnerable(true);
            });
            g.displayId = spawned.getUniqueId();
        }

        Entity holo = g.holoId == null ? null : Bukkit.getEntity(g.holoId);
        if (holo == null || !holo.isValid()) {
            Location loc = new Location(w, g.pos.x() + 0.5, g.pos.y() + 1.45, g.pos.z() + 0.5);
            TextDisplay spawned = w.spawn(loc, TextDisplay.class, t -> {
                t.text(holoText(g, tier));
                t.setBillboard(Display.Billboard.CENTER);
                t.setAlignment(TextDisplay.TextAlignment.CENTER);
                t.setBackgroundColor(Color.fromARGB(90, 0, 0, 0));
                t.setShadowed(true);
                t.setPersistent(false);
            });
            g.holoId = spawned.getUniqueId();
        }
    }

    private void removeEntities(PlacedGenerator g) {
        for (UUID id : new UUID[]{g.displayId, g.holoId}) {
            if (id == null) continue;
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
        g.displayId = null;
        g.holoId = null;
    }

    private void refreshHolo(PlacedGenerator g) {
        Tier tier = plugin.catalog().tier(g.tierId);
        if (tier == null || g.holoId == null) return;
        Entity e = Bukkit.getEntity(g.holoId);
        if (e instanceof TextDisplay t) {
            t.text(holoText(g, tier));
        }
    }

    private Component holoText(PlacedGenerator g, Tier tier) {
        return Component.join(JoinConfiguration.newlines(),
                plugin.lang().components("hologram", resolvers(tier, g.level, g.stored)));
    }

    private TagResolver[] resolvers(Tier t, int level, long stored) {
        CoinType coin = plugin.catalog().coin(t.coinId());
        return new TagResolver[]{
                Placeholder.parsed("tier", t.name()),
                Placeholder.parsed("coin", coin == null ? t.coinId() : coin.name()),
                Placeholder.unparsed("level", String.valueOf(level)),
                Placeholder.unparsed("max_level", String.valueOf(t.maxLevel())),
                Placeholder.unparsed("amount", Lang.fmt(t.amountAt(level))),
                Placeholder.unparsed("interval", String.valueOf(t.intervalSeconds())),
                Placeholder.unparsed("capacity", Lang.fmt(t.capacityAt(level))),
                Placeholder.unparsed("stored", Lang.fmt(stored)),
                Placeholder.unparsed("cost", Lang.fmt(t.upgradeCost(level)))
        };
    }

    // ---------- storage (YAML for now, SQLite planned) ----------

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        int i = 0;
        for (PlacedGenerator g : gens.values()) {
            String p = "gens." + i++;
            y.set(p + ".world", g.pos.world().toString());
            y.set(p + ".x", g.pos.x());
            y.set(p + ".y", g.pos.y());
            y.set(p + ".z", g.pos.z());
            y.set(p + ".owner", g.owner.toString());
            y.set(p + ".tier", g.tierId);
            y.set(p + ".level", g.level);
            y.set(p + ".stored", g.stored);
            y.set(p + ".progress", g.progress);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Could not save data.yml: " + ex.getMessage());
        }
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("gens");
        if (s == null) return;
        for (String key : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(key);
            if (c == null) continue;
            try {
                BlockPos pos = new BlockPos(UUID.fromString(c.getString("world", "")),
                        c.getInt("x"), c.getInt("y"), c.getInt("z"));
                PlacedGenerator g = new PlacedGenerator(pos,
                        UUID.fromString(c.getString("owner", "")),
                        c.getString("tier", ""), Math.max(1, c.getInt("level", 1)));
                g.stored = c.getLong("stored");
                g.progress = c.getInt("progress");
                gens.put(pos, g);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Skipping broken generator entry '" + key + "'.");
            }
        }
        plugin.getLogger().info("Loaded " + gens.size() + " generators.");
    }
}

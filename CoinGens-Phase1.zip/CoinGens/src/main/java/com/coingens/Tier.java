package com.coingens;

import org.bukkit.Material;

/** A generator tier loaded from generators.yml. */
public record Tier(String id, String name, Material block, String model, String coinId,
                   int intervalSeconds, long baseAmount, long baseCapacity,
                   int maxLevel, long baseUpgradeCost) {

    public long amountAt(int level) {
        return baseAmount * level;
    }

    public long capacityAt(int level) {
        return baseCapacity * level;
    }

    /** Cost to go from the given level to the next one. */
    public long upgradeCost(int level) {
        return baseUpgradeCost * level;
    }
}

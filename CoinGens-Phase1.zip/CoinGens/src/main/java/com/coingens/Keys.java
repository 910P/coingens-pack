package com.coingens;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

public final class Keys {
    public final NamespacedKey coin;
    public final NamespacedKey genTier;
    public final NamespacedKey genLevel;

    public Keys(Plugin plugin) {
        coin = new NamespacedKey(plugin, "coin");
        genTier = new NamespacedKey(plugin, "gen_tier");
        genLevel = new NamespacedKey(plugin, "gen_level");
    }
}

package com.coingens;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/** Holds all coin types and generator tiers. */
public final class Catalog {
    private final Map<String, CoinType> coins = new LinkedHashMap<>();
    private final Map<String, Tier> tiers = new LinkedHashMap<>();
    private List<CoinType> coinsByValueDesc = List.of();

    public void load(FileConfiguration cfg, Logger log) {
        coins.clear();
        tiers.clear();

        ConfigurationSection cs = cfg.getConfigurationSection("coins");
        if (cs != null) {
            for (String id : cs.getKeys(false)) {
                ConfigurationSection c = cs.getConfigurationSection(id);
                if (c == null) continue;
                coins.put(id, new CoinType(
                        id,
                        c.getString("name", id),
                        c.getString("model", "coingens:coin_" + id),
                        Math.max(1L, c.getLong("value", 1L))));
            }
        }
        coinsByValueDesc = coins.values().stream()
                .sorted(Comparator.comparingLong(CoinType::value).reversed())
                .toList();
        if (coins.values().stream().noneMatch(c -> c.value() == 1L)) {
            log.warning("generators.yml: define a coin with value 1, otherwise change can get lost!");
        }

        ConfigurationSection ts = cfg.getConfigurationSection("tiers");
        if (ts != null) {
            for (String id : ts.getKeys(false)) {
                ConfigurationSection t = ts.getConfigurationSection(id);
                if (t == null) continue;
                String coin = t.getString("coin", "");
                if (!coins.containsKey(coin)) {
                    log.warning("Tier '" + id + "' skipped: unknown coin '" + coin + "'.");
                    continue;
                }
                Material mat = Material.matchMaterial(t.getString("block", "STONE"));
                if (mat == null || !mat.isBlock()) {
                    log.warning("Tier '" + id + "': invalid block, using STONE.");
                    mat = Material.STONE;
                }
                tiers.put(id, new Tier(
                        id,
                        t.getString("name", id),
                        mat,
                        t.getString("model", "coingens:gen_" + id),
                        coin,
                        Math.max(1, t.getInt("interval", 10)),
                        Math.max(1L, t.getLong("amount", 1L)),
                        Math.max(1L, t.getLong("capacity", 64L)),
                        Math.max(1, t.getInt("max-level", 10)),
                        Math.max(1L, t.getLong("upgrade-cost", 100L))));
            }
        }
        log.info("Loaded " + coins.size() + " coin types and " + tiers.size() + " generator tiers.");
    }

    public CoinType coin(String id) {
        return id == null ? null : coins.get(id);
    }

    public Tier tier(String id) {
        return id == null ? null : tiers.get(id);
    }

    public Collection<String> coinIds() {
        return coins.keySet();
    }

    public Collection<String> tierIds() {
        return tiers.keySet();
    }

    public List<CoinType> coinsByValueDesc() {
        return coinsByValueDesc;
    }
}

package com.coingens;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

/** MiniMessage based language handling. Files live in plugins/CoinGens/lang/. */
public final class Lang {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final CoinGensPlugin plugin;
    private YamlConfiguration cfg = new YamlConfiguration();

    public Lang(CoinGensPlugin plugin) {
        this.plugin = plugin;
    }

    public static Component mm(String text, TagResolver... resolvers) {
        return MM.deserialize(text, resolvers)
                .decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static String fmt(long number) {
        return NumberFormat.getIntegerInstance(Locale.US).format(number);
    }

    public void load() {
        String code = plugin.getConfig().getString("language", "en_US");
        String path = "lang/" + code + ".yml";
        if (plugin.getResource(path) == null && !new File(plugin.getDataFolder(), path).exists()) {
            plugin.getLogger().warning("Unknown language '" + code + "', falling back to en_US.");
            path = "lang/en_US.yml";
        }
        File file = new File(plugin.getDataFolder(), path);
        if (!file.exists()) {
            plugin.saveResource(path, false);
        }
        cfg = YamlConfiguration.loadConfiguration(file);
        // Missing keys fall back to the bundled English file.
        try (InputStream in = plugin.getResource("lang/en_US.yml")) {
            if (in != null) {
                cfg.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (Exception ignored) {
            // defaults are optional
        }
    }

    public Component component(String key, TagResolver... resolvers) {
        return mm(cfg.getString(key, "<red>Missing message: " + key), resolvers);
    }

    public List<Component> components(String key, TagResolver... resolvers) {
        return cfg.getStringList(key).stream().map(s -> mm(s, resolvers)).toList();
    }

    public void send(CommandSender to, String key, TagResolver... resolvers) {
        to.sendMessage(component("prefix").append(component(key, resolvers)));
    }

    public void sendLines(CommandSender to, String key, TagResolver... resolvers) {
        for (Component line : components(key, resolvers)) {
            to.sendMessage(line);
        }
    }
}

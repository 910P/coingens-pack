package com.coingens;

import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class CoinGensPlugin extends JavaPlugin {
    private Keys keys;
    private Lang lang;
    private Catalog catalog;
    private CoinManager coins;
    private GeneratorManager generators;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "generators.yml").exists()) {
            saveResource("generators.yml", false);
        }
        keys = new Keys(this);
        lang = new Lang(this);
        catalog = new Catalog();
        coins = new CoinManager(this);
        generators = new GeneratorManager(this);

        lang.load();
        loadCatalog();
        generators.start();

        getServer().getPluginManager().registerEvents(new GeneratorListener(this), this);
        PluginCommand command = getCommand("coingens");
        if (command != null) {
            CoinGensCommand handler = new CoinGensCommand(this);
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        getLogger().info("CoinGens enabled.");
    }

    @Override
    public void onDisable() {
        if (generators != null) generators.stop();
    }

    public void reloadAll() {
        reloadConfig();
        lang.load();
        loadCatalog();
        generators.refreshAll();
    }

    private void loadCatalog() {
        catalog.load(YamlConfiguration.loadConfiguration(new File(getDataFolder(), "generators.yml")), getLogger());
    }

    public Keys keys() { return keys; }
    public Lang lang() { return lang; }
    public Catalog catalog() { return catalog; }
    public CoinManager coins() { return coins; }
    public GeneratorManager generators() { return generators; }
}

package com.coingens;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class GeneratorListener implements Listener {
    private final CoinGensPlugin plugin;

    public GeneratorListener(CoinGensPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        ItemStack item = e.getItemInHand();
        Tier tier = plugin.generators().tierOf(item);
        if (tier == null) return;

        Player p = e.getPlayer();
        int max = plugin.getConfig().getInt("limits.max-generators-per-player", 20);
        if (!p.hasPermission("coingens.admin") && plugin.generators().countOwned(p.getUniqueId()) >= max) {
            e.setCancelled(true);
            plugin.lang().send(p, "limit-reached", Placeholder.unparsed("max", String.valueOf(max)));
            return;
        }
        Block b = e.getBlockPlaced();
        plugin.generators().place(b, tier, plugin.generators().levelOf(item), p.getUniqueId());
        plugin.lang().send(p, "placed");
        p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.6f, 1.4f);
        b.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, b.getLocation().add(0.5, 1, 0.5), 10, 0.3, 0.3, 0.3, 0);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        GeneratorManager.PlacedGenerator g = plugin.generators().at(e.getBlock());
        if (g == null) return;
        Player p = e.getPlayer();
        if (!canUse(p, g)) {
            e.setCancelled(true);
            plugin.lang().send(p, "not-owner");
            return;
        }
        e.setDropItems(false);
        e.setExpToDrop(0);
        plugin.generators().pickup(p, g);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block block = e.getClickedBlock();
        if (block == null) return;
        GeneratorManager.PlacedGenerator g = plugin.generators().at(block);
        if (g == null) return;

        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        boolean empty = hand.getType().isAir();

        if (p.isSneaking()) {
            if (!empty) return; // normal sneak-placing next to the generator
            e.setCancelled(true);
            if (!canUse(p, g)) {
                plugin.lang().send(p, "not-owner");
                return;
            }
            plugin.generators().upgrade(p, g);
            return;
        }
        if (!empty && hand.getType().isBlock()) return; // allow placing blocks against it
        e.setCancelled(true);
        if (!canUse(p, g)) {
            plugin.lang().send(p, "not-owner");
            return;
        }
        plugin.generators().collect(p, g);
    }

    private boolean canUse(Player p, GeneratorManager.PlacedGenerator g) {
        return g.owner.equals(p.getUniqueId()) || p.hasPermission("coingens.admin");
    }

    // ---------- protection ----------

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.generators().at(b) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.generators().at(b) != null);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (e.getBlocks().stream().anyMatch(b -> plugin.generators().at(b) != null)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (e.getBlocks().stream().anyMatch(b -> plugin.generators().at(b) != null)) e.setCancelled(true);
    }
}

package com.coingens;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

public final class CoinGensCommand implements CommandExecutor, TabCompleter {
    private final CoinGensPlugin plugin;

    public CoinGensCommand(CoinGensPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        Lang lang = plugin.lang();
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            lang.sendLines(s, s.hasPermission("coingens.admin") ? "help-admin" : "help");
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "balance" -> {
                if (!(s instanceof Player p)) {
                    lang.send(s, "players-only");
                    return true;
                }
                lang.send(p, "balance",
                        Placeholder.unparsed("value", Lang.fmt(plugin.coins().valueIn(p.getInventory()))));
            }
            case "give" -> give(s, a);
            case "coins" -> coins(s, a);
            case "reload" -> {
                if (!s.hasPermission("coingens.admin")) {
                    lang.send(s, "no-permission");
                    return true;
                }
                plugin.reloadAll();
                lang.send(s, "reloaded");
            }
            default -> lang.sendLines(s, s.hasPermission("coingens.admin") ? "help-admin" : "help");
        }
        return true;
    }

    private void give(CommandSender s, String[] a) {
        Lang lang = plugin.lang();
        if (!s.hasPermission("coingens.admin")) {
            lang.send(s, "no-permission");
            return;
        }
        if (a.length < 3) {
            lang.send(s, "usage-give");
            return;
        }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) {
            lang.send(s, "player-not-found");
            return;
        }
        Tier tier = plugin.catalog().tier(a[2].toLowerCase(Locale.ROOT));
        if (tier == null) {
            lang.send(s, "unknown-tier");
            return;
        }
        int level = 1;
        int amount = 1;
        try {
            if (a.length > 3) level = Integer.parseInt(a[3]);
            if (a.length > 4) amount = Integer.parseInt(a[4]);
        } catch (NumberFormatException ex) {
            lang.send(s, "invalid-number");
            return;
        }
        level = Math.max(1, Math.min(level, tier.maxLevel()));
        amount = Math.max(1, Math.min(amount, 64));
        target.getInventory().addItem(plugin.generators().createItem(tier, level, amount)).values()
                .forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
        lang.send(s, "given-generator",
                Placeholder.parsed("tier", tier.name()),
                Placeholder.unparsed("player", target.getName()),
                Placeholder.unparsed("amount", String.valueOf(amount)));
    }

    private void coins(CommandSender s, String[] a) {
        Lang lang = plugin.lang();
        if (!s.hasPermission("coingens.admin")) {
            lang.send(s, "no-permission");
            return;
        }
        if (a.length < 4) {
            lang.send(s, "usage-coins");
            return;
        }
        Player target = Bukkit.getPlayerExact(a[1]);
        if (target == null) {
            lang.send(s, "player-not-found");
            return;
        }
        CoinType type = plugin.catalog().coin(a[2].toLowerCase(Locale.ROOT));
        if (type == null) {
            lang.send(s, "unknown-coin");
            return;
        }
        long amount;
        try {
            amount = Long.parseLong(a[3]);
        } catch (NumberFormatException ex) {
            lang.send(s, "invalid-number");
            return;
        }
        amount = Math.max(1L, Math.min(amount, 100_000L));
        plugin.coins().giveType(target, type, amount);
        lang.send(s, "given-coins",
                Placeholder.parsed("coin", type.name()),
                Placeholder.unparsed("player", target.getName()),
                Placeholder.unparsed("amount", Lang.fmt(amount)));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] a) {
        boolean admin = s.hasPermission("coingens.admin");
        if (a.length == 1) {
            List<String> options = new ArrayList<>(List.of("help", "balance"));
            if (admin) options.addAll(List.of("give", "coins", "reload"));
            return filter(options, a[0]);
        }
        if (!admin) return List.of();
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (a.length == 2 && (sub.equals("give") || sub.equals("coins"))) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), a[1]);
        }
        if (a.length == 3 && sub.equals("give")) return filter(plugin.catalog().tierIds(), a[2]);
        if (a.length == 3 && sub.equals("coins")) return filter(plugin.catalog().coinIds(), a[2]);
        return List.of();
    }

    private List<String> filter(Collection<String> options, String typed) {
        String t = typed.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(t)).toList();
    }
}

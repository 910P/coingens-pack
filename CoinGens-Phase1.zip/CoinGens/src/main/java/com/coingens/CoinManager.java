package com.coingens;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/** Creates coin items and handles paying with them. */
public final class CoinManager {
    private final CoinGensPlugin plugin;

    public CoinManager(CoinGensPlugin plugin) {
        this.plugin = plugin;
    }

    public ItemStack create(CoinType type, int amount) {
        ItemStack item = new ItemStack(Material.GOLD_NUGGET, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Lang.mm(type.name()));
        meta.lore(plugin.lang().components("coin-lore",
                Placeholder.unparsed("value", Lang.fmt(type.value()))));
        NamespacedKey model = NamespacedKey.fromString(type.model());
        if (model != null) {
            meta.setItemModel(model);
        }
        meta.getPersistentDataContainer().set(plugin.keys().coin, PersistentDataType.STRING, type.id());
        item.setItemMeta(meta);
        return item;
    }

    /** Returns the coin type of an item, or null if it is not a coin. */
    public CoinType typeOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer()
                .get(plugin.keys().coin, PersistentDataType.STRING);
        return plugin.catalog().coin(id);
    }

    /** Total value (in base coins) of all coins in the inventory. */
    public long valueIn(Inventory inv) {
        long total = 0;
        for (ItemStack stack : inv.getStorageContents()) {
            CoinType type = typeOf(stack);
            if (type != null) total += type.value() * stack.getAmount();
        }
        return total;
    }

    /** Takes the given value from the player's coins and hands back change. */
    public boolean charge(Player player, long cost) {
        PlayerInventory inv = player.getInventory();
        long total = valueIn(inv);
        if (total < cost) return false;
        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            if (typeOf(contents[i]) != null) contents[i] = null;
        }
        inv.setStorageContents(contents);
        long change = total - cost;
        if (change > 0) give(player, change);
        return true;
    }

    /** Gives the given value as the fewest coins possible. */
    public void give(Player player, long value) {
        for (CoinType type : plugin.catalog().coinsByValueDesc()) {
            long count = value / type.value();
            value -= count * type.value();
            giveType(player, type, count);
        }
    }

    public void giveType(Player player, CoinType type, long amount) {
        if (type == null) return;
        while (amount > 0) {
            int chunk = (int) Math.min(64L, amount);
            player.getInventory().addItem(create(type, chunk)).values()
                    .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
            amount -= chunk;
        }
    }
}

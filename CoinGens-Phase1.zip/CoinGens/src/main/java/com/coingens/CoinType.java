package com.coingens;

/** A coin item type. Name is a MiniMessage string, value is the worth in base coins. */
public record CoinType(String id, String name, String model, long value) {
}
